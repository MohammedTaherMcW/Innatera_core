import os
def process():
    print("Hello from custom process")